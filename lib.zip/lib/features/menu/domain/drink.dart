import 'package:cloud_firestore/cloud_firestore.dart';

class Drink {
  final String id;
  final String name;
  final int quantity;
  final String? updatedByName;
  final DateTime? updatedAt;

  Drink({required this.id, required this.name, required this.quantity, this.updatedByName, this.updatedAt});

  // Factory konstruktor koji kreira Drink iz Firestore dokumenta
  factory Drink.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data()!;
    return Drink(
      id: doc.id,
      name: data['name'] as String? ?? 'N/A',
      quantity: (data['quantity'] as num?)?.toInt() ?? 0,
      updatedByName: data['updatedByName'] as String?,
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
    );
  }
}
