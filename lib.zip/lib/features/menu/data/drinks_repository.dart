import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

class DrinksRepository {
  final _fs = FirebaseFirestore.instance;

  Future<void> confirm({
    required String cafeId,
    required String? updatedByUid,
    required String? updatedByName,
    required Map<String, Change> changes,
    required Map<String, int> originalQty,
    required Map<String, int> localQty,
    required bool writeLog, // {drinkId: Change}
  }) async {
    // 1) Batch za PIĆA (količine + meta)
    final batch = _fs.batch();
    final drinksCol = _fs.collection('cafes').doc(cafeId).collection('drinks');

    for (final entry in changes.entries) {
      final drinkId = entry.key;
      final ch = entry.value;
      if (ch.delta == 0) continue;

      batch.update(drinksCol.doc(drinkId), {
        'quantity': FieldValue.increment(ch.delta),
        'updatedAt': FieldValue.serverTimestamp(),
        'updatedBy': updatedByUid,
        'updatedByName': updatedByName,
      });
    }

    await batch.commit(); // ako batch prođe, količine su snimljene ✅

    // 2) ODVOJEN log zapis – da ne sruši batch ako padne
    final items = changes.entries
        .where((e) => e.value.delta != 0)
        .map(
          (e) => {
            'drinkId': e.key,
            'name': e.value.name,
            'from': e.value.from,
            'to': e.value.to,
            'delta': e.value.delta,
          },
        )
        .toList();

    if (items.isEmpty) return; // ništa realno nije promijenjeno

    final logsCol = _fs.collection('cafes').doc(cafeId).collection('logs');
    try {
      await logsCol.add({
        'when': FieldValue.serverTimestamp(),
        'byUid': updatedByUid,
        'byName': updatedByName ?? updatedByUid,
        'items': items,
      });
    } catch (e) {
      debugPrint('LOG WRITE FAILED: $e'); // ne rušimo UX ako log padne
    }
  }

  watchDrinks(String cafeId) {}
}

/// Jednostavan model za promjene
class Change {
  final String name;
  final int from;
  final int to;
  int get delta => to - from;

  Change({required this.name, required this.from, required this.to});
}
