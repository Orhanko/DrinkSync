import 'package:flutter/material.dart';
import 'package:drinksync/features/logs/data/logs_repository.dart';
import 'package:drinksync/features/logs/domain/log_record.dart';

class LogsScreen extends StatelessWidget {
  final String cafeId;
  const LogsScreen({super.key, required this.cafeId});

  @override
  Widget build(BuildContext context) {
    final repo = LogsRepository();
    return StreamBuilder<List<LogRecord>>(
      stream: repo.streamLogs(cafeId),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final records = snap.data ?? const [];
        if (records.isEmpty) {
          return const Center(child: Text('Nema logova.'));
        }
        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: records.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final r = records[i];
            final when = r.createdAt != null ? TimeOfDay.fromDateTime(r.createdAt!).format(context) : '';
            final details = [
              if (r.before != null && r.after != null) ' ${r.before} → ${r.after}',
              if (r.delta != null) ' (Δ ${r.delta})',
            ].join('');
            final who = r.updatedByName ?? r.updatedBy ?? 'nepoznato';

            return ListTile(
              leading: const Icon(Icons.history),
              title: Text('Artikal: ${r.drinkId}$details'),
              subtitle: Text('By: $who • $when'),
            );
          },
        );
      },
    );
  }
}
